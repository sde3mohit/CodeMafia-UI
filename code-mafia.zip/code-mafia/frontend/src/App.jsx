import { useState, useRef, useEffect, useMemo } from 'react'
import Home from './pages/Home'
import EnterName from './pages/EnterName'
import Lobby from './pages/Lobby'
import RoleReveal from './pages/RoleReveal'
import VoteCategory from './pages/VoteCategory'
import GameRound from './pages/GameRound'
import EmergencyMeeting from './pages/EmergencyMeeting'
import Results from './pages/Results'
import { PAGES } from './constants/pages'
import { getFakeExistingPlayers, FAKE_HOST_ID } from './mocks/fakeLobbyData'
import { getNextPlayerColor } from './utils/playerColor'
import { generatePlayerId } from './utils/generateId'
import { generateLobbyCode } from './utils/generateLobbyCode'
import { assignRoles } from './utils/assignRoles'
import { TOTAL_ROUNDS } from './constants/gameConfig'

const FIRST_ROUND = 1
const IMPOSTER_ROLE = 'imposter'
const CIVILIAN_ROLE = 'civilian'
const WINNER_CIVILIANS = 'civilians'
const WINNER_IMPOSTER = 'imposter'
const SUBMIT_DELAY_MS = 1000
const START_DELAY_MS = 1000
const DEFAULT_CATEGORY = 'Data Structures & Algorithms'

function App() {
  const [page, setPage] = useState(PAGES.HOME)

  const [pendingLobbyId, setPendingLobbyId] = useState('')
  const [joinError, setJoinError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState('')

  const [lobbyCode, setLobbyCode] = useState('')
  const [players, setPlayers] = useState([])
  const [hostId, setHostId] = useState('')
  const [myPlayerId, setMyPlayerId] = useState('')
  const [starting, setStarting] = useState(false)
  const [myRole, setMyRole] = useState(null)
  const [selectedCategory, setSelectedCategory] = useState('')
  const [allRoles, setAllRoles] = useState({})
  const [winner, setWinner] = useState(null)
  const [round, setRound] = useState(FIRST_ROUND)
  const [remountKey, setRemountKey] = useState(0)

  const submitTimeoutRef = useRef(null)
  const startTimeoutRef = useRef(null)

  useEffect(() => {
    return () => {
      if (submitTimeoutRef.current) clearTimeout(submitTimeoutRef.current)
      if (startTimeoutRef.current) clearTimeout(startTimeoutRef.current)
    }
  }, [])

  // Sends the game to Results with a given winner and resets round state.
  const endGame = (winningSide) => {
    setWinner(winningSide)
    setRound(FIRST_ROUND)
    setPage(PAGES.RESULTS)
  }

  const handleCreateGame = () => {
    setPendingLobbyId('')
    setSubmitError('')
    setPage(PAGES.ENTER_NAME_CREATE)
  }

  const handleJoinGame = (lobbyId) => {
    setPendingLobbyId(lobbyId)
    setJoinError('')
    setSubmitError('')
    setPage(PAGES.ENTER_NAME_JOIN)
  }

  const handleClearJoinError = () => setJoinError('')

  const handleBackToHome = () => {
    setPage(PAGES.HOME)
    setSubmitError('')
  }

  const handleAllTestsPassed = () => {
    const next = round + 1
    if (next > TOTAL_ROUNDS) {
      endGame(WINNER_CIVILIANS)
      return
    }
    setRound(next)
  }

  const handleSubmitName = (name) => {
    const trimmedName = name?.trim()
    if (!trimmedName) {
      setSubmitError('Name cannot be empty')
      return
    }

    setSubmitting(true)
    setSubmitError('')

    const isCreate = page === PAGES.ENTER_NAME_CREATE

    submitTimeoutRef.current = setTimeout(() => {
      setSubmitting(false)

      if (isCreate) {
        const newPlayerId = generatePlayerId()
        setMyPlayerId(newPlayerId)
        setLobbyCode(generateLobbyCode())
        setHostId(newPlayerId)

        const me = {
          id: newPlayerId,
          name: trimmedName,
          color: getNextPlayerColor([]),
          isReady: true,
          isActive: true,
        }

        const fakeCompanions = []
        const takenSoFar = [me]

        getFakeExistingPlayers().forEach((p) => {
          const companion = { ...p, color: getNextPlayerColor(takenSoFar) }
          fakeCompanions.push(companion)
          takenSoFar.push(companion)
        })

        setPlayers([me, ...fakeCompanions])
        setPage(PAGES.LOBBY)
        return
      }

      if (!pendingLobbyId) {
        setSubmitError('No lobby ID provided')
        return
      }

      const newPlayerId = generatePlayerId()
      setMyPlayerId(newPlayerId)

      const fakeExistingPlayers = getFakeExistingPlayers()
      setHostId(FAKE_HOST_ID)
      setLobbyCode(pendingLobbyId)
      setPlayers([
        ...fakeExistingPlayers,
        {
          id: newPlayerId,
          name: trimmedName,
          color: getNextPlayerColor(fakeExistingPlayers),
          isReady: false,
          isActive: true,
        },
      ])
      setPage(PAGES.LOBBY)
    }, SUBMIT_DELAY_MS)
  }

  const handleToggleReady = () => {
    setPlayers((prev) =>
      prev.map((p) => (p.id === myPlayerId ? { ...p, isReady: !p.isReady } : p))
    )
  }

  const handleStartGame = () => {
    if (starting) return
    setStarting(true)

    startTimeoutRef.current = setTimeout(() => {
      setStarting(false)

      const { roles, ok } = assignRoles(players)

      if (!ok) {
        setSubmitError('Could not start game — not enough players')
        setPage(PAGES.LOBBY)
        return
      }

      setAllRoles(roles)
      setRound(FIRST_ROUND)
      setRemountKey(0)
      const role = roles[myPlayerId] ?? CIVILIAN_ROLE
      setMyRole(role)
      setPage(PAGES.ROLE_REVEAL)
    }, START_DELAY_MS)
  }

  const handleRoleRevealComplete = () => {
    setPage(PAGES.VOTE_CATEGORY)
  }

  const handleVoteComplete = (category) => {
    setSelectedCategory(category ?? DEFAULT_CATEGORY)
    setPage(PAGES.GAME_ROUND)
  }

  const handleEmergencyMeeting = () => {
    setPage(PAGES.EMERGENCY_MEETING)
  }

  const handleMeetingComplete = (ejectedId) => {
    if (!ejectedId) {
      setRemountKey((prev) => prev + 1)
      setPage(PAGES.GAME_ROUND)
      return
    }

    const updatedPlayers = players.map((p) =>
      p.id === ejectedId ? { ...p, isActive: false } : p
    )
    setPlayers(updatedPlayers)

    if (allRoles[ejectedId] === IMPOSTER_ROLE) {
      endGame(WINNER_CIVILIANS)
      return
    }

    const activeCivilians = updatedPlayers.filter(
      (p) => p.isActive && allRoles[p.id] !== IMPOSTER_ROLE
    ).length

    if (activeCivilians <= 1) {
      endGame(WINNER_IMPOSTER)
      return
    }

    setRemountKey((prev) => prev + 1)
    setPage(PAGES.GAME_ROUND)
  }

  const handlePlayAgain = () => {
    setWinner(null)
    setPlayers([])
    setMyRole(null)
    setAllRoles({})
    setRound(FIRST_ROUND)
    setRemountKey(0)
    setLobbyCode('')
    setHostId('')
    setMyPlayerId('')
    setSelectedCategory('')
    setPage(PAGES.HOME)
  }

  const isHost = myPlayerId !== '' && myPlayerId === hostId
  const myPlayer = players.find((p) => p.id === myPlayerId)
  const isReady = myPlayer?.isReady ?? false

  const displayPlayers = useMemo(
    () =>
      players.map((p) => ({
        ...p,
        isHost: p.id === hostId,
        isYou: p.id === myPlayerId,
      })),
    [players, hostId, myPlayerId]
  )

  return (
    <>
      {page === PAGES.HOME && (
        <Home
          onCreateGame={handleCreateGame}
          onJoinGame={handleJoinGame}
          joinError={joinError}
          onClearJoinError={handleClearJoinError}
        />
      )}

      {page === PAGES.ENTER_NAME_CREATE && (
        <EnterName
          mode="create"
          onBack={handleBackToHome}
          onSubmitName={handleSubmitName}
          submitting={submitting}
          submitError={submitError}
        />
      )}

      {page === PAGES.ENTER_NAME_JOIN && (
        <EnterName
          mode="join"
          onBack={handleBackToHome}
          onSubmitName={handleSubmitName}
          submitting={submitting}
          submitError={submitError}
        />
      )}

      {page === PAGES.LOBBY && (
        <Lobby
          lobbyCode={lobbyCode}
          players={displayPlayers}
          isHost={isHost}
          isReady={isReady}
          onToggleReady={handleToggleReady}
          onStartGame={handleStartGame}
          starting={starting}
        />
      )}

      {page === PAGES.ROLE_REVEAL && (
        <RoleReveal role={myRole} onRevealComplete={handleRoleRevealComplete} />
      )}

      {page === PAGES.VOTE_CATEGORY && (
        <VoteCategory
          myPlayerId={myPlayerId}
          fakePlayerIds={players.filter((p) => p.id !== myPlayerId).map((p) => p.id)}
          onVoteComplete={handleVoteComplete}
        />
      )}

      {page === PAGES.GAME_ROUND && (
        <GameRound
          key={`${round}-${remountKey}`}
          category={selectedCategory}
          players={displayPlayers}
          round={round}
          onEmergencyCall={handleEmergencyMeeting}
          onAllTestsPassed={handleAllTestsPassed}
        />
      )}

      {page === PAGES.EMERGENCY_MEETING && (
        <EmergencyMeeting
          players={displayPlayers}
          callerName={myPlayer?.name ?? 'Unknown caller'}
          myPlayerId={myPlayerId}
          allRoles={allRoles}
          onMeetingComplete={handleMeetingComplete}
        />
      )}

      {page === PAGES.RESULTS && (
        <Results
          winner={winner}
          players={displayPlayers}
          allRoles={allRoles}
          onPlayAgain={handlePlayAgain}
        />
      )}

      {!Object.values(PAGES).includes(page) && (
        <p className="font-pixel text-pixel-red text-center mt-10">
          Unknown page: "{page}"
        </p>
      )}
    </>
  )
}

export default App